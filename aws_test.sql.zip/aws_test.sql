-- phpMyAdmin SQL Dump
-- version 4.4.15.5
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1:3306
-- Время создания: Авг 20 2017 г., 18:35
-- Версия сервера: 5.5.48
-- Версия PHP: 5.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `aws_test`
--

-- --------------------------------------------------------

--
-- Структура таблицы `done_day`
--

CREATE TABLE IF NOT EXISTS `done_day` (
  `id` int(11) NOT NULL,
  `done` varchar(64) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=175 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `done_day`
--

INSERT INTO `done_day` (`id`, `done`, `userid`) VALUES
(173, 'Third day task', 14),
(174, 'Third day taks', 15);

-- --------------------------------------------------------

--
-- Структура таблицы `done_month`
--

CREATE TABLE IF NOT EXISTS `done_month` (
  `id` int(11) NOT NULL,
  `done` varchar(255) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `done_month`
--

INSERT INTO `done_month` (`id`, `done`, `userid`) VALUES
(1, 'Third month task', 14),
(2, 'Month task', 15);

-- --------------------------------------------------------

--
-- Структура таблицы `done_week`
--

CREATE TABLE IF NOT EXISTS `done_week` (
  `id` int(11) NOT NULL,
  `done` varchar(255) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `done_year`
--

CREATE TABLE IF NOT EXISTS `done_year` (
  `id` int(11) NOT NULL,
  `done` varchar(255) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `done_year`
--

INSERT INTO `done_year` (`id`, `done`, `userid`) VALUES
(1, 'Third year task', 14);

-- --------------------------------------------------------

--
-- Структура таблицы `files`
--

CREATE TABLE IF NOT EXISTS `files` (
  `id` int(11) NOT NULL,
  `file` blob,
  `path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `notes`
--

CREATE TABLE IF NOT EXISTS `notes` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `text` varchar(2048) NOT NULL,
  `userid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(32) NOT NULL,
  `role` varchar(32) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `roles`
--

INSERT INTO `roles` (`id`, `role`) VALUES
(3, 'Child'),
(2, 'Father'),
(1, 'Mother');

-- --------------------------------------------------------

--
-- Структура таблицы `tasks_day`
--

CREATE TABLE IF NOT EXISTS `tasks_day` (
  `id` int(11) NOT NULL,
  `tasks` varchar(128) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `tasks_day`
--

INSERT INTO `tasks_day` (`id`, `tasks`, `userid`) VALUES
(3, 'First day task', 14),
(4, 'Second day task', 14),
(6, 'First day task', 15),
(7, 'Second day task', 15);

-- --------------------------------------------------------

--
-- Структура таблицы `tasks_month`
--

CREATE TABLE IF NOT EXISTS `tasks_month` (
  `id` int(11) NOT NULL,
  `tasks` varchar(255) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `tasks_month`
--

INSERT INTO `tasks_month` (`id`, `tasks`, `userid`) VALUES
(1, 'First month task', 14),
(2, 'Second month task', 14);

-- --------------------------------------------------------

--
-- Структура таблицы `tasks_week`
--

CREATE TABLE IF NOT EXISTS `tasks_week` (
  `id` int(11) NOT NULL,
  `tasks` varchar(255) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `tasks_week`
--

INSERT INTO `tasks_week` (`id`, `tasks`, `userid`) VALUES
(8, 'Week task', 14);

-- --------------------------------------------------------

--
-- Структура таблицы `tasks_year`
--

CREATE TABLE IF NOT EXISTS `tasks_year` (
  `id` int(11) NOT NULL,
  `tasks` varchar(255) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `tasks_year`
--

INSERT INTO `tasks_year` (`id`, `tasks`, `userid`) VALUES
(1, 'First year task', 14),
(2, 'Second year task', 14),
(3, 'Year', 15);

-- --------------------------------------------------------

--
-- Структура таблицы `upl_task`
--

CREATE TABLE IF NOT EXISTS `upl_task` (
  `task` varchar(1024) DEFAULT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `upl_task`
--

INSERT INTO `upl_task` (`task`, `userid`) VALUES
('Cleaning\r', 0),
('Homework\r', 0),
('Reading books\r', 0),
('Buy milk\r', 0),
('Walk with dogs\r', 0),
('Go to the library', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(32) NOT NULL,
  `login` varchar(32) DEFAULT NULL,
  `pass` varchar(128) DEFAULT NULL,
  `roleid` int(32) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `pass`, `roleid`) VALUES
(14, 'Anna', 'b2ca678b4c936f905fb82f2733f5297f', 1),
(15, 'Peter', 'b2ca678b4c936f905fb82f2733f5297f', 2),
(16, 'Mike', 'b2ca678b4c936f905fb82f2733f5297f', 3),
(17, 'Tina', 'b2ca678b4c936f905fb82f2733f5297f', 3),
(18, 'Test', 'b2ca678b4c936f905fb82f2733f5297f', NULL),
(24, 'Kolobok', '098f6bcd4621d373cade4e832627b4f6', 2),
(25, 'Fedor', 'b2ca678b4c936f905fb82f2733f5297f', 3);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `done_day`
--
ALTER TABLE `done_day`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `done` (`done`),
  ADD KEY `userid` (`userid`);

--
-- Индексы таблицы `done_month`
--
ALTER TABLE `done_month`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `done` (`done`),
  ADD KEY `userid` (`userid`);

--
-- Индексы таблицы `done_week`
--
ALTER TABLE `done_week`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `done` (`done`),
  ADD KEY `userid` (`userid`);

--
-- Индексы таблицы `done_year`
--
ALTER TABLE `done_year`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `done` (`done`),
  ADD KEY `userid` (`userid`);

--
-- Индексы таблицы `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `userid` (`userid`);

--
-- Индексы таблицы `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `role` (`role`);

--
-- Индексы таблицы `tasks_day`
--
ALTER TABLE `tasks_day`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userid` (`userid`);

--
-- Индексы таблицы `tasks_month`
--
ALTER TABLE `tasks_month`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tasks` (`tasks`),
  ADD KEY `userid` (`userid`);

--
-- Индексы таблицы `tasks_week`
--
ALTER TABLE `tasks_week`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tasks` (`tasks`),
  ADD KEY `userid` (`userid`);

--
-- Индексы таблицы `tasks_year`
--
ALTER TABLE `tasks_year`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tasks` (`tasks`),
  ADD KEY `userid` (`userid`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`),
  ADD KEY `roleid` (`roleid`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `done_day`
--
ALTER TABLE `done_day`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=175;
--
-- AUTO_INCREMENT для таблицы `done_month`
--
ALTER TABLE `done_month`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT для таблицы `done_week`
--
ALTER TABLE `done_week`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT для таблицы `done_year`
--
ALTER TABLE `done_year`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `files`
--
ALTER TABLE `files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `notes`
--
ALTER TABLE `notes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(32) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT для таблицы `tasks_day`
--
ALTER TABLE `tasks_day`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT для таблицы `tasks_month`
--
ALTER TABLE `tasks_month`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT для таблицы `tasks_week`
--
ALTER TABLE `tasks_week`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT для таблицы `tasks_year`
--
ALTER TABLE `tasks_year`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(32) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=26;
--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `done_month`
--
ALTER TABLE `done_month`
  ADD CONSTRAINT `done_month_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

--
-- Ограничения внешнего ключа таблицы `done_week`
--
ALTER TABLE `done_week`
  ADD CONSTRAINT `done_week_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

--
-- Ограничения внешнего ключа таблицы `done_year`
--
ALTER TABLE `done_year`
  ADD CONSTRAINT `done_year_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

--
-- Ограничения внешнего ключа таблицы `notes`
--
ALTER TABLE `notes`
  ADD CONSTRAINT `notes_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

--
-- Ограничения внешнего ключа таблицы `tasks_day`
--
ALTER TABLE `tasks_day`
  ADD CONSTRAINT `tasks_day_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `tasks_month`
--
ALTER TABLE `tasks_month`
  ADD CONSTRAINT `tasks_month_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

--
-- Ограничения внешнего ключа таблицы `tasks_week`
--
ALTER TABLE `tasks_week`
  ADD CONSTRAINT `tasks_week_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

--
-- Ограничения внешнего ключа таблицы `tasks_year`
--
ALTER TABLE `tasks_year`
  ADD CONSTRAINT `tasks_year_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

--
-- Ограничения внешнего ключа таблицы `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`roleid`) REFERENCES `roles` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
