-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 05, 2018 at 01:19 
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `todo`
--

-- --------------------------------------------------------

--
-- Table structure for table `done_day`
--

CREATE TABLE `done_day` (
  `id` int(11) NOT NULL,
  `done` varchar(64) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `done_month`
--

CREATE TABLE `done_month` (
  `id` int(11) NOT NULL,
  `done` varchar(255) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `done_week`
--

CREATE TABLE `done_week` (
  `id` int(11) NOT NULL,
  `done` varchar(255) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `done_year`
--

CREATE TABLE `done_year` (
  `id` int(11) NOT NULL,
  `done` varchar(255) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `notes`
--

CREATE TABLE `notes` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `text` varchar(2048) NOT NULL,
  `userid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(32) NOT NULL,
  `role` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `role`) VALUES
(3, 'Child'),
(2, 'Father'),
(1, 'Mother');

-- --------------------------------------------------------

--
-- Table structure for table `tasks_day`
--

CREATE TABLE `tasks_day` (
  `id` int(11) NOT NULL,
  `tasks` varchar(128) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tasks_month`
--

CREATE TABLE `tasks_month` (
  `id` int(11) NOT NULL,
  `tasks` varchar(255) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tasks_week`
--

CREATE TABLE `tasks_week` (
  `id` int(11) NOT NULL,
  `tasks` varchar(255) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tasks_year`
--

CREATE TABLE `tasks_year` (
  `id` int(11) NOT NULL,
  `tasks` varchar(255) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `upl_task`
--

CREATE TABLE `upl_task` (
  `task` varchar(1024) DEFAULT NULL,
  `datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(32) NOT NULL,
  `login` varchar(32) DEFAULT NULL,
  `pass` varchar(128) DEFAULT NULL,
  `roleid` int(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `login`, `pass`, `roleid`) VALUES
(14, 'Anna', 'b2ca678b4c936f905fb82f2733f5297f', 1),
(15, 'Peter', 'b2ca678b4c936f905fb82f2733f5297f', 2),
(16, 'Mike', 'b2ca678b4c936f905fb82f2733f5297f', 3),
(17, 'Tina', 'b2ca678b4c936f905fb82f2733f5297f', 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `done_day`
--
ALTER TABLE `done_day`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `done` (`done`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `done_month`
--
ALTER TABLE `done_month`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `done` (`done`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `done_week`
--
ALTER TABLE `done_week`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `done` (`done`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `done_year`
--
ALTER TABLE `done_year`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `done` (`done`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `role` (`role`);

--
-- Indexes for table `tasks_day`
--
ALTER TABLE `tasks_day`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `tasks_month`
--
ALTER TABLE `tasks_month`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tasks` (`tasks`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `tasks_week`
--
ALTER TABLE `tasks_week`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tasks` (`tasks`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `tasks_year`
--
ALTER TABLE `tasks_year`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tasks` (`tasks`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`),
  ADD KEY `roleid` (`roleid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `done_day`
--
ALTER TABLE `done_day`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=206;
--
-- AUTO_INCREMENT for table `done_month`
--
ALTER TABLE `done_month`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `done_week`
--
ALTER TABLE `done_week`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `done_year`
--
ALTER TABLE `done_year`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `notes`
--
ALTER TABLE `notes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(32) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tasks_day`
--
ALTER TABLE `tasks_day`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=720;
--
-- AUTO_INCREMENT for table `tasks_month`
--
ALTER TABLE `tasks_month`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `tasks_week`
--
ALTER TABLE `tasks_week`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tasks_year`
--
ALTER TABLE `tasks_year`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(32) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `done_month`
--
ALTER TABLE `done_month`
  ADD CONSTRAINT `done_month_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

--
-- Constraints for table `done_week`
--
ALTER TABLE `done_week`
  ADD CONSTRAINT `done_week_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

--
-- Constraints for table `done_year`
--
ALTER TABLE `done_year`
  ADD CONSTRAINT `done_year_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

--
-- Constraints for table `notes`
--
ALTER TABLE `notes`
  ADD CONSTRAINT `notes_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

--
-- Constraints for table `tasks_day`
--
ALTER TABLE `tasks_day`
  ADD CONSTRAINT `tasks_day_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `tasks_month`
--
ALTER TABLE `tasks_month`
  ADD CONSTRAINT `tasks_month_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

--
-- Constraints for table `tasks_week`
--
ALTER TABLE `tasks_week`
  ADD CONSTRAINT `tasks_week_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

--
-- Constraints for table `tasks_year`
--
ALTER TABLE `tasks_year`
  ADD CONSTRAINT `tasks_year_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`roleid`) REFERENCES `roles` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
